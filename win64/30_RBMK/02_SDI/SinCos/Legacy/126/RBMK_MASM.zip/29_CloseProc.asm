CloseWndProc proc hWnd:QWORD

;Prologue:
push rbp
mov rbp,rsp

and rsp,-16 ;Align the Stack
sub rsp,100h ;Create the Buffer

mov hWnd,rcx

;mov rcx,hWnd
lea rdx,szMsgCloseText ;"Exit?"
lea r8,szMainWndTitle ;"RBMK-1000 OpenGL Environment"
mov r9,24h ;MB_YESNO Or MB_ICONQUESTION
Call MessageBoxA
cmp rax,6 ;IDYES
jne lbl_CloseWndProc_End

lea rcx,hAccTable
Call DestroyAcceleratorTable

xor rcx,rcx
xor rdx,rdx
Call wglMakeCurrent

mov rcx,ghRC
Call wglDeleteContext

mov rcx,hWnd
mov rdx,ghDC
Call ReleaseDC

mov rcx,hWnd
Call DestroyWindow

lbl_CloseWndProc_End:
;Epilogue:
leave
ret
CloseWndProc endp

