;lbl_SetView:

mov rcx, 4100h;GL_COLOR_BUFFER_BIT Or GL_DEPTH_BUFFER_BIT
Call glClear

;Set Object
mov rcx,1700h ;GL_MODELVIEW
Call glMatrixMode

Call glLoadIdentity

movss xmm0,aXY_Model
xorps xmm1,xmm1
xorps xmm2,xmm2
movss xmm3,f32_1
Call glRotatef ;(aXY_Model, 0, 0, 1)

movss xmm0,aYZ_Model
movss xmm1,f32_1
xorps xmm2,xmm2
xorps xmm3,xmm3
Call glRotatef ;(aYZ_Model, 1, 0, 0)

movss xmm0,aXZ_Model
xorps xmm1,xmm1
movss xmm2,f32_1
xorps xmm3,xmm3
Call glRotatef ;(aXZ_Model, 0, 1, 0)

;Set Camera
mov rcx,1701h ;GL_PROJECTION
Call glMatrixMode

Call glLoadIdentity

movsd xmm0,f64_90
movsd xmm1,RectAspect
movsd xmm2,f64_1
movsd xmm3,f64_MILLION
Call gluPerspective ;(90, RectAspect, 0.1, 1000000)

movss xmm0,aYZ_Cam
movss xmm1,f32_1
xorps xmm2,xmm2
xorps xmm3,xmm3
Call glRotatef ;(aYZ_Cam, 1, 0, 0) '1-CameraTilt

movss xmm0,aXY_Cam
xorps xmm1,xmm1
xorps xmm2,xmm2
movss xmm3,f32_1
Call glRotatef ;(aXY_Cam, 0, 0, 1) '2-CameraTurn

movss xmm0,aXZ_Cam
xorps xmm1,xmm1
movss xmm2,f32_1
xorps xmm3,xmm3
Call glRotatef ;(aXZ_Cam, 0, 1, 0) '3-CameraRoll

movss xmm0,xCam
movss xmm1,yCam
movss xmm2,zCam
Call glTranslatef ;(xCam, yCam, zCam)

;lbl_SetView_End:
