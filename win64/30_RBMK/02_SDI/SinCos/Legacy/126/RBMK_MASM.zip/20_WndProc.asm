WndProc proc hWnd:QWORD, wMsg:QWORD, wParam:QWORD, lParam:QWORD
;CurPos POINT2D Structure must be Aligned by 10h in the Memory
;to Avoid the Error 80000002 (STATUS_DATATYPE_MISALIGNMENT)
;We'll declare it as a local Variable in DrawGLScene proc
LOCAL dummy:QWORD, CurPos:QWORD

;Prologue:
push rbp
mov rbp,rsp

and rsp,-16 ;Align the Stack
sub rsp,100h ;Create the Buffer

mov hWnd,rcx
mov wMsg,rdx
mov wParam,r8
mov lParam,r9

;Messages Arranged by Probability
cmp edx,200h
je lbl_wmMouseMove
cmp edx,100h
je lbl_wmKeyDown
cmp edx,101h
je lbl_wmKeyUp
cmp edx,201h
je lbl_wmLButtonDown
cmp edx,202h
je lbl_wmLButtonUp
cmp edx,204h
je lbl_wmRButtonDown
cmp edx,205h
je lbl_wmRButtonUp
cmp edx,207h
je lbl_wmMButtonDown
cmp edx,208h
je lbl_wmMButtonUp
cmp edx,209h
je lbl_wmMButtonDblClk
cmp edx,20Ah
je lbl_wmMouseWheel
cmp edx,111h
je lbl_wmCommand
cmp edx,6
je lbl_wmActivate
cmp edx,5
je lbl_wmSize
;cmp edx,112h
;je lbl_wmSysCommand
cmp edx,10h
je lbl_wmClose
cmp edx,2
je lbl_wmDestroy
;cmp edx,1
;je lbl_wmCreate

;None of the Above
lbl_DefWndProc:
call DefWindowProcA
jmp lbl_WndProc_End


;WM_CREATE = 1
;lbl_wmCreate:
;jmp lbl_WndProc_Return0


;WM_SIZE = 5
lbl_wmSize:
include 21_GLResize.asm
jmp lbl_WndProc_Return0


;WM_ACTIVATE = 6
lbl_wmActivate:
;LoWord Can Be WA_INACTIVE, WA_ACTIVE, WA_CLICKACTIVE
cmp r8w,0 ;LOWORD(wParam) != WA_INACTIVE
je lblDeActivate
;The High-Order Word Specifies The Minimized State Of The Window Being Activated Or Deactivated
mov rax,r8
shr rax,10h ;Shift Right 16 bits
cmp ax,0 ;Not Minimized when HIWORD(wParam) = 0
jne lblDeActivate

lblSetActive:
mov isActive,1
jmp lbl_WndProc_Return0
lblDeActivate:
mov isActive,0
jmp lbl_WndProc_Return0


;WM_KEYDOWN = 100h
lbl_wmKeyDown:
xor rax,rax
mov eax,r8d
mov nKeyCode,r8w ;LOWORD(wParam)
;Set 1 in the Array
lea rbx,key
add rax,rbx
mov dword ptr [rax],1

cmp nKeyCode,9 ;Tab
jne @f
;Object Turn Counter-Clockwise 30 degrees
movss xmm0,aXY_Model
addss xmm0,dTab ;30.0_f32 = 41F00000h
movss aXY_Model,xmm0
;Set Flags
mov isInitialPosition,0
mov isRefreshed,0
jmp lbl_WndProc_Return0

@@:
cmp nKeyCode,0Dh ;Enter
jne @f
;mov rcx,hWnd
call AboutProc
jmp lbl_WndProc_Return0

@@:
cmp nKeyCode,1Bh ;Esc
jne @f
cmp isInitialPosition,0
jne lbl_wmClose
call ReAssign
jmp lbl_WndProc_Return0

@@:
cmp nKeyCode,20h ;SpaceBar
jne @f
call ReAssign
jmp lbl_WndProc_Return0

@@:
cmp nKeyCode,70h ;F1
jne @f
call AboutProc
jmp lbl_WndProc_Return0

@@: ;Default
;mov isRefreshed,0
jmp lbl_WndProc_Return0

;WM_KEYUP = 101h
lbl_wmKeyUp:
xor rax,rax
mov eax,r8d
mov nKeyCode,r8w ;LOWORD(wParam)
lea rbx,key
add rax,rbx
mov byte ptr [rax],0
jmp lbl_WndProc_Return0


;WM_COMMAND = 111h
lbl_wmCommand:
cmp r8w,IDM_APP_EXIT
jne @f
jmp lbl_wmClose
@@:
cmp r8w,IDM_CAMERA_MODE_PLANAR
jne @f
mov nCameraMode,0
;Check/UnCheck
mov rcx,hMenuOptionsCamera
mov rdx,IDM_CAMERA_MODE_SPATIAL
xor r8,r8 ;MF_UNCHECKED
Call CheckMenuItem
mov rcx,hMenuOptionsCamera
mov rdx,IDM_CAMERA_MODE_PLANAR
mov r8,8 ;MF_CHECKED
Call CheckMenuItem
jmp lbl_WndProc_Return0
@@:
cmp r8w,IDM_CAMERA_MODE_SPATIAL
jne @f
mov nCameraMode,1
;Check/UnCheck
mov rcx,hMenuOptionsCamera
mov rdx,IDM_CAMERA_MODE_SPATIAL
mov r8,8 ;MF_CHECKED
Call CheckMenuItem
mov rcx,hMenuOptionsCamera
mov rdx,IDM_CAMERA_MODE_PLANAR
xor r8,r8 ;MF_UNCHECKED
Call CheckMenuItem
jmp lbl_WndProc_Return0
@@:
cmp r8w,IDM_HELP_ABOUT
jne lbl_WndProc_Return0
Call AboutProc
;If none of the above
jmp lbl_WndProc_Return0


;WM_SYSCOMMAND = 112h
;lbl_wmSysCommand:
;jmp lbl_WndProc_Return0


;WM_MOUSEMOVE = 200h
lbl_wmMouseMove:
;Select Mode
cmp nMouse,1 ;MOUSE_MODE_CAMERA_ROTATION = 1
je lbl_MouseTurn
cmp nMouse,2 ;MOUSE_MODE_CAMERA_ROLL = 2
je lbl_MouseRoll
cmp nMouse,3 ;MOUSE_MODE_CAMERA_PAN = 3
je lbl_MousePan
jmp lbl_WndProc_Return0
include 22_1_MouseTurn.asm
include 22_2_MouseRoll.asm
include 22_3_MousePan.asm

;WM_LBUTTONDOWN = 201h
lbl_wmLButtonDown:
;Toggle Mouse-Driven Camera Rotation
mov nMouse,1 ;MOUSE_MODE_CAMERA_ROTATION = 1
;Extract PrevPos.X
mov xPrevPos,r9d
and xPrevPos,0FFFFh
;Extract PrevPos.Y
mov yPrevPos,r9d
shr yPrevPos,16
;Set Flags
mov isInitialPosition,0
mov isRefreshed,0
jmp lbl_WndProc_Return0

;WM_LBUTTONUP = 202h
lbl_wmLButtonUp:
;Toggle Keyboard-Driven Camera Movement
mov nMouse,0 ;MOUSE_MODE_FREE_MOTION = 0
jmp lbl_WndProc_Return0

;WM_RBUTTONDOWN = 204h
lbl_wmRButtonDown:
;Toggle Mouse-Driven Camera Rolling
mov nMouse,2 ;MOUSE_MODE_CAMERA_ROLL = 2
;Extract PrevPos.X
mov xPrevPos,r9d
and xPrevPos,0FFFFh
;Extract PrevPos.Y
mov yPrevPos,r9d
shr yPrevPos,16
;Set UnRefreshed Flag
mov isRefreshed,0
jmp lbl_WndProc_Return0

;WM_RBUTTONUP = 205h
lbl_wmRButtonUp:
;Toggle Keyboard-Driven Camera Movement
mov nMouse,0 ;MOUSE_MODE_FREE_MOTION = 0
jmp lbl_WndProc_Return0

;WM_MBUTTONDOWN = 207h
lbl_wmMButtonDown:
;Toggle Mouse-Driven Camera Pan
mov nMouse,3 ;MOUSE_MODE_CAMERA_PAN = 3
;Extract PrevPos.X
mov xPrevPos,r9d
and xPrevPos,0FFFFh
;Extract PrevPos.Y
mov yPrevPos,r9d
shr yPrevPos,16
;Set Flags
mov isInitialPosition,0
mov isRefreshed,0
jmp lbl_WndProc_Return0

;WM_MBUTTONUP = 208h
lbl_wmMButtonUp:
;Toggle Keyboard-Driven Camera Movement
mov nMouse,0 ;MOUSE_MODE_FREE_MOTION = 0
jmp lbl_WndProc_Return0

;WM_MBUTTONDBLCLK = 209h
lbl_wmMButtonDblClk:
call ReAssign
jmp lbl_WndProc_Return0

;WM_MOUSEWHEEL = 20Ah
lbl_wmMouseWheel:
include 22_4_MouseZoom.asm
;Set UnRefreshed Flag
mov isRefreshed,0
jmp lbl_WndProc_Return0


;WM_CLOSE = 10h
lbl_wmClose:
mov rcx,hWnd
call CloseWndProc
jmp lbl_WndProc_Return0

;WM_DESTROY = 2
lbl_wmDestroy:
xor rcx,rcx
Call PostQuitMessage
;jmp lbl_WndProc_Return0


lbl_WndProc_Return0:
xor rax,rax
;jmp lbl_WndProc_End

lbl_WndProc_End:
;Epilogue:
leave
ret
WndProc endp
